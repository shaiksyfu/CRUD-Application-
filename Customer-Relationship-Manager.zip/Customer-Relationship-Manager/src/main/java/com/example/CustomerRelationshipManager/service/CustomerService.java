package com.example.CustomerRelationshipManager.service;

import java.util.List;

import com.example.CustomerRelationshipManager.entity.Customer;

public interface CustomerService {
	List<Customer> getAllcustomers();
	Customer saveCustomer(Customer customer);
	
	Customer getCustomerById(Long id);
	
	Customer updateCustomer(Customer Customer);
	
	void deleteCustomerById(Long id);
	
}
