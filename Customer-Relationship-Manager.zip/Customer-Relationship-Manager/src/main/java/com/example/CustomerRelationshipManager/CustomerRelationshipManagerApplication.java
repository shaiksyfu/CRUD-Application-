package com.example.CustomerRelationshipManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.CustomerRelationshipManager.entity.Customer;
import com.example.CustomerRelationshipManager.repository.CustomerRepository;

@SpringBootApplication
public class CustomerRelationshipManagerApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(CustomerRelationshipManagerApplication.class, args);
	}

	@Autowired
	private CustomerRepository customerRepository;
	@Override
	public void run(String... args) throws Exception {
		Customer customer1=new Customer("S.MD.","Syfuddin","syfuddinsyfuddin4013@gmail.com");
		customerRepository.save(customer1);
		
		Customer customer2=new Customer("Pawan","Kumar","pawanperumal@gmail.com");
		customerRepository.save(customer2);
		
		Customer customer3=new Customer("Ayub","ansari","ayubansaari@gmail.com");
		customerRepository.save(customer3);
	}

}
